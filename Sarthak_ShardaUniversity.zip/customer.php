<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="/docs/4.0/assets/img/favicons/favicon.ico">

    <title>Dashboard</title>
 <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

    <!-- Custom styles for this template -->
    <link href="css/admin_login.css" rel="stylesheet">


    <!-- Custom styles for this template -->
    <link href="dashboard.css" rel="stylesheet">
  </head>

  <body>
    <nav class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0">
      <!-- <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="#"></a> -->
       <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="#"><?php echo $_SESSION['username']; ?></a>
      <input class="form-control form-control-dark w-100" type="text" placeholder="Search" aria-label="Search">
      <ul class="navbar-nav px-3">
        <li class="nav-item text-nowrap">
          <a class="nav-link" href="logout.php">Sign out</a>
          <a class="nav-link" href="reset-password.php">Reset Password</a>
        </li>
      </ul>
    </nav>

    <div class="container-fluid">
      <div class="row">
        <nav class="col-md-2 d-none d-md-block bg-light sidebar">
          <div class="sidebar-sticky">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link active" href="#">
                  <span data-feather="home"></span>
                  Customers <span class="sr-only">(current)</span>
                </a>
              </li>
              <li class="nav-item">
           
              </li>
              <li class="nav-item">
         
              </li>
              <li class="nav-item">
                <a class="nav-link" href="customer.php">
                  <span data-feather="users"></span>
                  Customers
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="https://github.com/chikkz?tab=repositories">
                  <span data-feather="bar-chart-2"></span>
                  Github
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="https://coronagraph.live">
                  <span data-feather="layers"></span>
                  Corona Graph Live
                </a> 
              </li>
            </ul>

          
            </ul>
          </div>
        </nav>
           <main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">
           <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="welcome.php">Dashboard</a></li>
    <li class="breadcrumb-item"><a href="#">Customers</a></li>
    
  </ol>
          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
             <h1 class="h2">Customers</h1>
            <nav aria-label="breadcrumb">
 
</nav>
            <div class="btn-toolbar mb-2 mb-md-0">
              <div class="btn-group mr-2">
               
              </div>
              <a class="btn btn-primary" href="add_customer.php">Add Customer</a>
              
            </div>
          </div>

<table id="example" class="display" style="width:100%">
        <thead>
            <tr>
                <th>Serial No.</th>
                <th>Username</th>
                <th>Card Number</th>
                <th>Expiry Date</th>
                <th>CVV</th>
                <th>Card Type</th>
                <th>Action</th>
                
            </tr>
        </thead>
        <tbody>
          <?php 
include('db.php');
$query=mysqli_query($conn, "select * from customers");
while($row=mysqli_fetch_array($query))
{




?>
            
           
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['name']; ?></td>
                <td><?php echo $row['card_number']; ?></td>
                <td><?php echo $row['expiry_date']; ?></td>
                <td><?php echo $row['cvv']; ?></td>
                <td><?php echo $row['card_type']; ?></td>
                <td>
                  <div class="row">
                    <div class="btn-group">
                      <a href="customer_edit.php?edit=<?php echo $row['id']; ?>" class="btn btn-success">
                        <span class="glyphicon glyphicon-pencil"></span>
                      </a>
                       <a href="customer_delete.php?del=<?php echo $row['id']; ?>" class="btn btn-danger">
                        <span class="glyphicon glyphicon-trash"></span>
                      </a>
                      
                    </div>
                  </div>
                </td>
                
              </tr>
            <?php } ?>
                
        </tbody>
       
    </table>


          <canvas class="my-4" id="myChart" width="900" height="380"></canvas>

          
          <div class="table-responsive">
            
          </div>
        </main>
      </div>
    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
    <script src="../../assets/js/vendor/popper.min.js"></script>
    <script src="../../dist/js/bootstrap.min.js"></script>

    <!-- Icons -->
    <script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
    <script>
      feather.replace()
    </script>

   <!-- datatables plugin -->
   <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
   <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
   <script >
     $(document).ready(function() {
    $('#example').DataTable();
} );
   </script>
  </body>
</html>


     

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
    <script src="../../assets/js/vendor/popper.min.js"></script>
    <script src="../../dist/js/bootstrap.min.js"></script>

    <!-- Icons -->
    <script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
    <script>
      feather.replace()
    </script>

  
  </body>
</html>
