<?php 



include('db.php');
 $name=$_POST['name'];
 $card_number=$_POST['card_number'];
 $expiry_date=$_POST['expiry_date'];
 $cvv=$_POST['cvv'];
 $card_type=$_POST['card_type'];

$sql="INSERT INTO customers(name,card_number,expiry_date,cvv,card_type
) VALUES ($name','$card_number','$expiry_date','$cvv','$card_type')";
					$run_query=mysqli_query($conn,$sql);

var_dump(run_query);

if(run_query)
{
	echo "<div class='alert alert-success'>Data has been recorded</div>";
}
else
{
	echo "<div class='alert alert-danger'>Please try again</div>";
}
?>
