<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
 include('db.php');
 $conn=mysqli_connect("localhost", "root", "", "customers");
 $query= mysqli_query($conn,"select * from customers where name='{$_SESSION['name']}");
}
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="/docs/4.0/assets/img/favicons/favicon.ico">

    <title>Dashboard</title>
 <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

 

    <!-- Custom styles for this template -->
    <link href="dashboard.css" rel="stylesheet">
  </head>

  <body>
    <nav class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0">
      <!-- <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="#"></a> -->
       <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="#"><?php echo $_SESSION['username']; ?></a>
      <input class="form-control form-control-dark w-100" type="text" placeholder="Search" aria-label="Search">
      <ul class="navbar-nav px-3">
        <li class="nav-item text-nowrap">
          <a class="nav-link" href="logout.php">Sign out</a>
          <a class="nav-link" href="reset-password.php">Reset Password</a>
        </li>
      </ul>
    </nav>

    <div class="container-fluid">
      <div class="row">
        <nav class="col-md-2 d-none d-md-block bg-light sidebar">
          <div class="sidebar-sticky">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link active" href="#">
                  <span data-feather="home"></span>
                  Customers <span class="sr-only">(current)</span>
                </a>
              </li>
              <li class="nav-item">
              
              </li>
              <li class="nav-item">
            
              </li>
              <li class="nav-item">
                <a class="nav-link" href="customer.php">
                  <span data-feather="users"></span>
                  Customers
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="https://github.com/chikkz?tab=repositories">
                  <span data-feather="bar-chart-2"></span>
                  Github
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="https://coronagraph.live">
                  <span data-feather="layers"></span>
                  Corona Graph Live
                </a> 
              </li>
            </ul>

      
            </ul>
          </div>
        </nav>
           
        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">
           <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="welcome.php">Dashboard</a></li>
    <li class="breadcrumb-item"><a href="customer.php">Customers</a></li>
     <li class="breadcrumb-item"><a href="#">Add Customers</a></li>
    
  </ol>
          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
             <h1 class="h2">Add Customer</h1>
            <nav aria-label="breadcrumb">
 
</nav>
            <div class="btn-toolbar mb-2 mb-md-0">
              <div class="btn-group mr-2">
               
              </div>
              <!-- <a class="btn btn-primary" href="add_customer.php">Add Customer</a> -->
              
            </div>
          </div>
<div style="width: 60%; margin-left: 20%;  ">
  
    
  
  <form action="" method="post" style="margin: 3%; padding: 3%" name="customer_form" id="customer_form"> 
    <div id="msg"></div>
 <!--  <div class="form-group"> 
    <label for="">Enter Customer Email</label>
    <input type="email" name="email" id="email" class="form-control" placeholder="Enter Customer Email">
  
</div> -->
<div class="form-group"> 
    <label for="Customer Username">Enter Username</label>
    <input type="text" name="name" id="name" class="form-control" placeholder="Enter Customer Username">
  
</div>
<div class="form-group"> 
    <label for="Card Number">Enter Card Number</label>
    <input type="text" name="card_number" id="card_number" class="form-control" placeholder="Enter Card Number">
  
</div>
<div class="form-group"> 
    <label for="Expiry Date">Enter Expiry Date</label>
    <input type="date" name="expiry_date" id="expiry_date" class="form-control" placeholder="Enter Expiry Date">
  
</div>
<div class="form-group"> 
    <label for="text">Enter CVV</label>
    <input type="text" name="cvv" id="cvv" class="form-control" placeholder="Enter CVV">
  
</div>
<div class="form-group"> 
    <label for="text">Enter Card Type</label>
     <select name="card_type" name="card_type" id="card_type" class="form-control" id="card_type">
    <option value="1">Master Card</option>
    <option value="2">Discovery Card</option>
    <option value="3">Visa Card</option>
    <option value="4">Travel/Entertainment Card</option>
  </select>
</div>

  <div class="form-group"> 
    
    <input type="submit" class="btn btn-block btn-success" placeholder="Save" name="submit" id="submit">
  
</div>


</form>

          <canvas class="my-4" id="myChart" width="900" height="380"></canvas>

          
          <div class="table-responsive">
            
          </div>
        </main>
      </div>
    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
    <!-- <script src="../../assets/js/vendor/popper.min.js"></script> -->
    <!-- <script src="../../dist/js/bootstrap.min.js"></script> -->

    <!-- Icons -->
    <script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
    <script>
      feather.replace()
    </script>

   <!-- datatables plugin -->
   <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
   <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
   <script >
     $(document).ready(function() {
    $('#example').DataTable();
} );
   </script>
   <script>
         
    $(document).ready(function(){
      $("#submit").click(function(){
        
        var name=$("#name").val();
        var card_number=$("#card_number").val();
        var expiry_date=$("#expiry_date").val();
        var cvv=$("#cvv").val();
        var card_type=$("#card_type").val();
     
        var data=$("#customer_form").serialize();
        $.ajax({
          type:"POST",
          url:"Customer_add.php",
          data:data,
          success:function(data){
           $("#msg").html(data);
          }
        });
      });
    });


   </script>
  </body>
</html>
